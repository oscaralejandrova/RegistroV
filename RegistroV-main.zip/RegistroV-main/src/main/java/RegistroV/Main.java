/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RegistroV;

import java.util.ArrayList;

/**
 *
 * @author Bayron Vargas
 */
public class Main {
    
    public static ArrayList<Vehiculo> vehiculos = new ArrayList<>();
   
    public static ArrayList<Persona> personas = new ArrayList<>();
    
}
