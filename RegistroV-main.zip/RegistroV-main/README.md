# RegistroV
Programa con GUI para registrar datos y mostrarlos usando arraylist
